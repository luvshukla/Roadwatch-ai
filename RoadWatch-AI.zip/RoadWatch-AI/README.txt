RoadWatch AI

Open index.html in a browser. For camera and GPS, use an HTTPS host such as Replit or GitHub Pages.
